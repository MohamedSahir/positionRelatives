import { BrowserModule } from '@angular/platform-browser';
import{HttpModule} from '@angular/http';
import { NgModule } from '@angular/core';
import { ChartsModule } from 'ng2-charts';
import { AppComponent } from './app.component';
import { CountoModule }  from 'angular2-counto';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,ChartsModule,HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
