import { Component,  ViewChild ,ElementRef,OnInit, Inject} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {ChartsModule, Color} from 'ng2-charts';
import{WindEnergyService} from '../app/services/windenergy.service';
import{EnergyService} from '../app/services/wind.service';
import{IEnergy} from './services/Energy';
import{config} from './config';
import 'chart.js/src/chart';
declare var options:any;
declare var Chart :any;

@Component({
  selector: 'app-root',
  templateUrl: './testrel.component.html',
  styleUrls: ['./testrel.css'],
  providers: [EnergyService,WindEnergyService]
})


export class AppComponent implements OnInit {

  public options:any;
  public errorMsg :string ="10" ;
  public errornumber:number=62;
  public numbers :number[] =[];
  public numberss :IEnergy[];

  public emissionTotal:number[]=[];

title=""; 
num =0;
energies:IEnergy[];
emissionfreePercentage=0;
emissionfreeTitle="";

constructor(private _energyService:EnergyService,private _windEnergyService: WindEnergyService){
  
}

 ngOnInit(){
    console.log("ngInit hooked");




// Working Fine
     this._energyService.getEnergy().subscribe((response) => {
         let x=100;
         let y=100;
         console.log(this.numberss = response);
         this.num = response[0].EnergyValue;
         this.title =response[0].EnergyName;
         this.numbers[0] = response[0].EnergyValue;
         this.numbers[1]= x-response[0].EnergyValue;
         this.doughnutChartData= this.numbers;









         
         this.emissionfreePercentage = response[1].EnergyValue;
         this.emissionfreeTitle = response[1].EnergyName;
         this.emissionTotal[0] = response[1].EnergyValue;
         this.emissionTotal[1] = y- response[1].EnergyValue;
         this.doughnutChartDataEmission3 = this.emissionTotal;


         console.log(this.numbers[1])
        // 
     //this.doughnutChartData3 = this.numbers[0][1]
         //num=22;

        // console.log(num);
     }),(err)=> {this.errorMsg =<any>err};


  
    }
 
   ngAfterViewInit() {
  



    Chart.plugins.register({
      beforeDraw: function (chart) {
        if (chart.config.options.elements.center) {
          var ctx = chart.ctx;
          var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
          var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.5);

          //draws arc in the center
          chart.ctx.beginPath();
          chart.ctx.arc(centerX, (centerY + centerY / 4), chart.innerRadius, 0, 2 * Math.PI);
          chart.ctx.fillStyle = '#fff';
          chart.ctx.fill();
          chart.ctx.lineWidth = 5;
          chart.ctx.strokeStyle = '#fff';
          chart.ctx.stroke();
        }
      }
    });








  //   Chart.pluginService.register({
  //     beforeDraw: function (chart) {
  //       if (chart.config.options.elements.center) {
  //         //Get ctx from string
  //         var ctx = chart.chart.ctx;        
  //         //Get options from the center object in options
  //         var centerConfig = chart.config.options.elements.center;
  //         // var fontStyle = centerConfig.fontStyle || 'Arial';  
  //         var fontStyle = 'bold regular  MyriadPro'; 
  //         var txt = centerConfig.text;      
  //         var color = centerConfig.color || '#000';
  //         var sidePadding = centerConfig.sidePadding || 20;
  //         var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
  //         // ctx.font = "22px" + fontStyle;
          
  //         //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
  //         var stringWidth = ctx.measureText(txt).width;
  //         var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;
  
  //         // Find out how much the font can grow in width.
  //         var widthRatio = elementWidth / stringWidth;
  //         var newFontSize = Math.floor(30 * widthRatio);
  //         var elementHeight = (chart.innerRadius * 2);
  
  //         // Pick a new font size so it will not be larger than the height of label.
  //         var fontSizeToUse = Math.min(newFontSize, elementHeight);
  
  //         //Set font settings to draw it correctly.
  //         ctx.textAlign = 'center';
  //         ctx.textBaseline = 'middle';
  //         var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //         var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
  //        // ctx.font =  fontSizeToUse+"px" + fontStyle;
  //         //ctx.font ="1 0px italic Arial";
  //        // console.log(ctx.font);
  //        ctx.fillStyle = color;
    
  //        var array = txt.split("<br>");      
  //        for (var i = 0; i < array.length; i++) {
  //              // console.log(array);    
  //         if(i===0)
  //         {
  //           if(centerX<376)
  //           {  
  //             var centerXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //             var centerYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.3);
  //             ctx.font ="20pt  MyriadPro";
  //             ctx.fillText(array[0],centerXX,centerYY);                  
  //             centerY += 23;          
  //           }       
  //          else
  //          {
  //          var centerXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //          var centerYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.3);
  //          ctx.font ="bold  32pt  MyriadPro";
  //          ctx.fillText(array[0],centerXX,centerYY);
  //          centerYY += 53;           
  //          }
  //         }      
  //         else if(i!=0) {
  //           if(centerX<376 && centerX>250)
  //           {      
  //                 //  alert("x");
  //                 // console.log(centerX);
  //                   // var centerXXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //                   // var centerYYY = ((chart.chartArea.top + chart.chartArea.bottom) / 1.7); 
  //             ctx.font = "bold 10pt  MyriadPro"; 
  //             ctx.fillText(array[i],centerX,centerY);         
  //             centerY += 20;          
  //           }
  //           else if(centerX<250)
  //           {
  //             var centerXXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //             var centerYYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
  //             ctx.font ="bold 8pt MyriadPro";
  //             ctx.fillText(array[i],centerX,centerY-20);
  //             centerY+= 10;                      
  //           }             
  //           else {         
  //             ctx.font = "bold normal 17pt  MyriadPro",
  //             ctx.fillText(array[i],centerX,centerY);
  //              centerY += 50;
  //              }
  //           }
  //  }

  //       }
  //     }
  //   });

 

  } // end of ngAfterInit




// widget 2
public doughnutChartLabels:string[] = ['Wind Energy'];
public doughnutChartData:number[] = [];
public doughnutChartType:string = 'doughnut';
private doughnutChartColors1: any[] = [
   { 
    backgroundColor: ["rgba(255, 177, 62, 0.8)", "transparent"],
   // backgroundColor: ["rgba(255, 177, 61, 0.63)", "rgba(255,255,255,.3)"],
    borderColor: 'white',
    borderWidth: [2.5]
   }  
   
];

public doughnutChartOptions: any = {
 cutoutPercentage:55,
//  rotation: (90*Math.PI) - (2/90 * Math.PI),
rotation: (-0.5 * Math.PI) - (Math.PI),
 responsive: false,
 layout: {
  padding: {
      left: 0,
      right: 2,
      top: 10,
      bottom: 5
  }
 
},
 animaiton: {
  animateRotate: true,
  animateScale: true,
  animationDuration: 9000,
  rotation:9000,
  duration:9000
 }, 
  title: {
      display: false
  },
  legend: {
    display: false
},  




  elements: {
    center: {
     // text: this.errornumber + "%" +"Energy produced by the Wind", 
      text: this.errornumber +"% <br>Energy produced <br> by Wind Today" ,
      //fontColor: '#fff',
      //fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
     
      fontFamily:"'Arial'",
      //fontSize: ,
      fontStyle: 'Bold Italic'
    }
  }
};

// events
public chartClicked1(e:any):void {
  console.log(e);
}
public chartHovered1(e:any):void {
  console.log(e);
}









//widget 2
public doughnutChartLabels3:string[] = ['', ''];
public doughnutChartDataEmission3:number[] = [];
public doughnutChartEmission3: any[] = [
  { 
    // backgroundColor: ["rgba(255,255,255,.9)", "rgba(255,255,255,.3)"],
    //borderColor: 'black'
    //backgroundColor: ["rgba(255,255,255,.7)", "rgba(255,255,255)"],
    // backgroundColor: ["rgba(255,255,255,.7)", "rgba(3, 1, 4, 0)"],
    backgroundColor: ["rgba(255, 128, 0,0.7)", "rgba(255, 255, 255,0.15)"]
   }  
   
];

public doughnutChartData3:number[] = [350, 450, 100];
public doughnutChartType3:string = 'doughnut';

  public chartClicked3(e:any):void {
    console.log(e);
  }
 
  public chartHovered3(e:any):void {
    console.log(e);
  }





  public doughnutChartOptions3: any = {
    cutoutPercentage:55,
   //  rotation: (90*Math.PI) - (2/90 * Math.PI),
   rotation: (-0.5 * Math.PI) - (Math.PI),
    responsive: false,
    layout: {
      padding: {
        left: 0,
        right: 2,
        top: 10,
        bottom: 5
    }
    
   },
    animaiton: {
      animationSteps : 100,
     animateRotate: true,
     animateScale: true,
     animationDuration: 111,
     rotation:7000,
     duration:8000
    }, 
     title: {
         display: false
     },
     legend: {
       display: false
   },  
   
   
   
   
     elements: {
       center: {
        // text: this.errornumber + "%" +"Energy produced by the Wind", 
         text: this.errornumber +"% <br>Energy produced <br> by Wind Today" ,
         //fontColor: '#fff',
         //fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
        
         fontFamily:"'Arial'",
         //fontSize: ,
         fontStyle: 'Bold Italic'
       }
     }
   };





} // end of component



