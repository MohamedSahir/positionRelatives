import {Injectable} from '@angular/core';
import{Http,Response} from '@angular/http';
import{Observable} from 'rxjs/Observable';
import{IEnergy} from '../services/Energy';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
@Injectable()
export class EnergyService{    
 constructor(private _http:Http)
    {     
    }   
    private _energyUrl ="../data/energy.json";

    getEnergy(): Observable <IEnergy[]>{   
            return this._http.get(this._energyUrl)
            .map((response:Response) =>  <IEnergy[]> response.json())
            .catch(this.handleError);
     }     
    private handleError(error:Response){
            alert(error);
            return Observable.throw(error.json().error || "server error");
            }
}































//private _energyUrl ="../data/energy.json";