import {Injectable} from '@angular/core';
import{Http,Response} from '@angular/http';
import{Observable} from 'rxjs/Observable';
import{IEnergy} from '../services/Energy';


@Injectable()
export class WindEnergyService{
   private _energyUrl ="../api/url"; 
    
    
    getWindEnergy():IEnergy[] 
    {
        return[{      
                "EnergyID":1,
                "EnergyName":"Wind Energy",
                "EnergyValue":20
               },
                {
                "EnergyID":3,
                "EnergyName":"Nuclear Energy",
                "EnergyValue":19.96
             },
             {
                    "EnergyID":2,
                    "EnergyName":"Nuclear Energy",
                    "EnergyValue":20.96
             }     
    ]
}




}