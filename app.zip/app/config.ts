export var config = {
    energyString: "%<br>Energy produced <br> by Wind Today",
    fontName:"Arial"
  }