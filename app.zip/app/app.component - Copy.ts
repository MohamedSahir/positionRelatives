import { Component,  ViewChild ,ElementRef} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {ChartsModule, Color} from 'ng2-charts';

declare var options:any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  //@ViewChild('layout') canvasRef;
  @ViewChild("layout") layout: ElementRef; 
  @ViewChild('mycanvas')canvas:ElementRef; 

  public options:any;

  ngAfterViewInit() {


    // let canvas = this.layout.nativeElement;
    // // let context = canvas.getContext('2d');

    // //  var x = canvas.width / 2;
    // // var y = canvas.height / 2;
    // let context: CanvasRenderingContext2D = this.layout.nativeElement.getContext("2d");
    // var x = canvas.width / 2;
    // var y = canvas.height / 2;
    
    // context.font = '90pt Calibri';
    // context.textAlign = 'center';
    // context.fillStyle = 'blue';
    // context.fillText('Hello Worldetrereygerhg!', x, y);
    





// Method 2

var ctx = this.canvas.nativeElement.getContext("2d");
    let me = this;
    this.options = {
      circumference: Math.PI,
      rotation :  Math.PI,
      animation:{ onComplete: function() {
         me.doit(ctx);
       }}
    }
  }

  doit(ctx) {
    alert("triggered");
    //   Chart.types.Doughnut.prototype.draw.apply(this, arguments);

       var width = this.canvas.nativeElement.clientWidth,
           height = this.canvas.nativeElement.clientHeight;

       var fontSize = (height / 250).toFixed(2);
       ctx.font = fontSize + "em Verdana";
       ctx.textBaseline = "middle";
       ctx.fillStyle = "blue";

       var text = "Pass Rate 82%",
           textX = Math.round((width - ctx.measureText(text).width) / 2),
           textY = height -10;

       ctx.fillText(text, textX, textY);
       ctx.restore();
   }

   public pieChartLabels:string[] = ['Wind Energy', 'Total Energy', 'Nuclear Energy'];
   public pieChartData:number[] = [300, 500, 10];
   public pieChartType:string = 'pie';
  
   public chartClicked(e:any):void {
    
   }
  
   public chartHovered(e:any):void {
   
   }

// widget 2
public doughnutChartLabels:string[] = ['Wind Energy'];
public doughnutChartData:number[] = [62,38];
public doughnutChartType:string = 'doughnut';
private doughnutChartColors: any[] = [
  { 
    backgroundColor: ["rgb(242, 163, 106)", "white"],
   
   },  
   
   {borderColor: ['black']
}
];

// events
public chartClicked1(e:any):void {
  console.log(e);
}
public chartHovered1(e:any):void {
  console.log(e);
}


// colorsEmptyObject: Array<Color> = [{}];

// //
// name:string;
// labels:string[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
// data:number[] = [350, 450, 100];
// type:string = 'doughnut';



// datasets: any[] = [
//   {
//     data: this.data,
//     backgroundColor: [
//       "#FFFFFF",
//       "#36A2EB",
//       "#FFCE56"
//     ],
//     hoverBackgroundColor: [
//       "#000",
//       "#36A2EB",
//       "#FFCE56"
//     ]
//   }];

}

