// import { Component,  ViewChild ,ElementRef,OnInit, Inject} from '@angular/core';
// import {BrowserModule} from '@angular/platform-browser';
// import {ChartsModule, Color} from 'ng2-charts';
// import{WindEnergyService} from '../app/services/windenergy.service';
// import{EnergyService} from '../app/services/wind.service';
// import{IEnergy} from './services/Energy';
// import{config} from './config';
// import 'chart.js/src/chart';
// declare var options:any;
// declare var Chart :any;

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css'],
//   providers: [EnergyService,WindEnergyService]
// })


// export class AppComponent implements OnInit {
//   //@ViewChild('layout') canvasRef;
// //  @ViewChild("layout") layout: ElementRef; 
//   //@ViewChild('mycanvas')canvas:ElementRef; 
//   //@ViewChild('mycanvas1')canvas1:ElementRef; 
//  // @ViewChild('mycanvas3')mycanvas3:ElementRef;
 
//   public options:any;
//   public errorMsg :string ="10" ;
//   public errornumber:number=62;
//   public numbers :number[] =[40];
//   public numberss :IEnergy[];
//   // texts:string="'/n</br>'fjgidfjgidgh" ;
// title=""; 
// num =0;
// energies:IEnergy[];
// emissionfreePercentage=0;
// emissionfreeTitle="";
// // Energies=
// // [ 
// //   {"EnergyID":1,"EnergyName":"Wind Energy","EnergyValue":19.96},
// //   {"EnergyID":3,"EnergyName":"Phones","EnergyValue":19.96},
// //   {"EnergyID":2,"EnergyName":"Laptop","EnergyValue":20.96}
// // ]
// constructor(private _energyService:EnergyService,private _windEnergyService: WindEnergyService){
  
// }

//  ngOnInit(){
//     console.log("ngInit hooked");

// //let Energing = this.Energies;


// // this.energies = this._windEnergyService.getWindEnergy();
// // this.num= this.energies[0].EnergyValue;
// // this.title =this.energies[0].EnergyName;
// // this.numbers[0] = this.energies[0].EnergyValue;

// // console.log(this.energies);



// // Working Fine
//      this._energyService.getEnergy().subscribe((response) => {
//          let x=100;
//          console.log(this.numberss = response);
//          this.num = response[0].EnergyValue;
//          this.title =response[0].EnergyName;
//          this.numbers[0] = response[0].EnergyValue;
//          this.numbers[1]= x-response[0].EnergyValue;
         
//          this.emissionfreePercentage = response[1].EnergyValue;
//          this.emissionfreeTitle = response[1].EnergyName;



//          console.log(this.numbers[1])
//          this.doughnutChartData= this.numbers;
//          //num=22;

//         // console.log(num);
//      }),(err)=> {this.errorMsg =<any>err};

  
//       // let ctx = this.canvas.nativeElement.getContext("2d");
//       // console.log(ctx);
//       // let me = this;
//       // this.options = {
//       //   circumference: Math.PI,
//       //   rotation :  Math.PI,
//       //   animation:{ onComplete: function() {
//       //      me.doit(ctx);
//       //    }}
//       // }
//     }
 
//    ngAfterViewInit() {
  
  
 












//     // Chart.pluginService.register({
//     //   afterDraw: function (chart) {
//     //     if (chart.config.options.elements.center) {
//     //       var helpers = Chart.helpers;
//     //       var centerX = (chart.chartArea.left + chart.chartArea.right) / 2;
//     //       var centerY = (chart.chartArea.top + chart.chartArea.bottom) / 2;
//     //       var ctx = chart.chart.ctx;
//     //       ctx.save();
//     //       var fontSize = helpers.getValueOrDefault(chart.config.options.elements.center.fontSize, Chart.defaults.global.defaultFontSize);
//     //       var fontStyle = helpers.getValueOrDefault(chart.config.options.elements.center.fontStyle, Chart.defaults.global.defaultFontStyle);
//     //       var fontFamily = helpers.getValueOrDefault(chart.config.options.elements.center.fontFamily, Chart.defaults.global.defaultFontFamily);
//     //       var font = helpers.fontString(fontSize, fontStyle, fontFamily);
//     //       ctx.font = font;
//     //       ctx.fillStyle = helpers.getValueOrDefault(chart.config.options.elements.center.fontColor, Chart.defaults.global.defaultFontColor);
//     //       ctx.textAlign = 'center';
//     //       ctx.textBaseline = 'middle';
//     //       ctx.fillText(chart.config.options.elements.center.text, centerX, centerY);
//     //       ctx.restore();
//     //     }
//     //   },
//     // })

//     Chart.pluginService.register({
//       beforeDraw: function (chart) {
//         if (chart.config.options.elements.center) {
//           //Get ctx from string
//           var ctx = chart.chart.ctx;        
//           //Get options from the center object in options
//           var centerConfig = chart.config.options.elements.center;
//           // var fontStyle = centerConfig.fontStyle || 'Arial';  
//           var fontStyle = 'bold regular  MyriadPro'; 
//           var txt = centerConfig.text;      
//           var color = centerConfig.color || '#000';
//           var sidePadding = centerConfig.sidePadding || 20;
//           var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
//           // ctx.font = "22px" + fontStyle;
          
//           //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
//           var stringWidth = ctx.measureText(txt).width;
//           var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;
  
//           // Find out how much the font can grow in width.
//           var widthRatio = elementWidth / stringWidth;
//           var newFontSize = Math.floor(30 * widthRatio);
//           var elementHeight = (chart.innerRadius * 2);
  
//           // Pick a new font size so it will not be larger than the height of label.
//           var fontSizeToUse = Math.min(newFontSize, elementHeight);
  
//           //Set font settings to draw it correctly.
//           ctx.textAlign = 'center';
//           ctx.textBaseline = 'middle';
//           var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
//           var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
//          // ctx.font =  fontSizeToUse+"px" + fontStyle;
//           //ctx.font ="1 0px italic Arial";
//          // console.log(ctx.font);
//          ctx.fillStyle = color;
    












//           // var img = new Image();
//           // // img.src = 'https://developers.google.com/maps/images/lhimages/api/icon_streetviewimageapi.svg';

//           // // var fillPattern = ctx.createPattern(img, 'repeat');



//           // var words = txt.split(' ');
//           // var line = '';
//           // for(var n = 0; n < words.length; n++) {
//           //   var testLine = line + words[n] + ' ';
//           //   var metrics = stringWidth;
//           //   var testWidth = metrics.width;
//           //   if (testWidth > stringWidth && n > 0) {
//           //     ctx.fillText(line, centerX, centerY);
//           //     line = words[n] + ' ';
//           //     centerY += elementHeight;
//           //   }
//           //   else {
//           //     line = testLine;
//           //   }
//           // }

      
//           // console.log(centerX);
//           // if(centerX<376){
//           //           var array = txt.split("<br>");
//           //           for (var i = 0; i < array.length; i++) {
//           //           ctx.fillText(array[i], centerX,centerY);
//           //           centerY += 23;
          
//           //           }
//           //         }
//           //           else{       
//           //             var array = txt.split("<br>");
//           //             for (var i = 0; i < array.length; i++) {
//           //             ctx.fillText(array[i], centerX,centerY);
//           //             centerY += 43;
//           //           }
          
          
//           //          }       
//           //         }
//           //       }








//                                     //ctx.fillText(txt, centerX, centerY);
         
       
//                         // ctx.font = "200"+"px" + "bold Arial";
       





//          var array = txt.split("<br>");      
//          for (var i = 0; i < array.length; i++) {
//                // console.log(array);    
//           if(i===0)
//           {
//             if(centerX<376)
//             {  
//               var centerXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
//               var centerYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.3);
//               ctx.font ="20pt  MyriadPro";
//               ctx.fillText(array[0],centerXX,centerYY);                  
//               centerY += 23;          
//             }       
//            else
//            {
//            var centerXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
//            var centerYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.3);
//            ctx.font ="bold  32pt  MyriadPro";
//            ctx.fillText(array[0],centerXX,centerYY);
//            centerYY += 53;           
//            }
//           }      
//           else if(i!=0) {
//             if(centerX<376 && centerX>250)
//             {      
//                   //  alert("x");
//                   // console.log(centerX);
//                     // var centerXXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
//                     // var centerYYY = ((chart.chartArea.top + chart.chartArea.bottom) / 1.7); 
//               ctx.font = "bold 10pt  MyriadPro"; 
//               ctx.fillText(array[i],centerX,centerY);         
//               centerY += 20;          
//             }
//             else if(centerX<250)
//             {
//               var centerXXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
//               var centerYYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
//               ctx.font ="bold 8pt MyriadPro";
//               ctx.fillText(array[i],centerX,centerY-20);
//                              // centerYYY += 133;  
              
//               centerY+= 10;
//                       //  alert("13");     
//             }             
//             else {
//                     //  alert("14");
//                     // console.log(centerX);
//                     // ctx.font = "20pt bold regular MyriadPro",
//              ctx.font = "bold normal 17pt  MyriadPro",
//               ctx.fillText(array[i],centerX,centerY);
//                centerY += 50;
//                }
//             }



































//               // ctx.font ="20px italic Arial";
//               //  var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
//               //  var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.1);
              
//                 //ctx.fillText(array[i], centerX,centerY);
//    }













       
















//           //wrapText(ctx, txt, centerX, centerY, widthRatio, elementHeight);

//           // console.log(txt);
//           // var lines = txt.split("\n");
//           // for (var i = 0; i < lines.length; ++i) {
          
        
//           // }

//         //  var text = txt;
          
//         //  // text.replace('E', '<br/><br/>');

//         //   txt= text.replace(/\n/g, " " ).split( " " ) ;
//         //   console.log(txt);
      
//         // ctx.fillText(txt, centerX, centerY);
        



//           //Draw text in center
//           //ctx.fillText(txt, centerX, centerY);
//         }
//       }
//     });

 
   
  
  








  
//      // let context = canvas.getContext('2d');
//     // let can = this.layout.nativeElement;
//     // let ctx = can.getContext('2d');
//     //   ctx.fillStyle = "blue";
//     //   ctx.font = "20pt Verdana";
//     //   ctx.textAlign = "center";
//     //   ctx.textBaseline = "middle";
//     //  let step = 0;
//     //  let steps = can.height + 50;
  
//   }

//     // let canvas = this.layout.nativeElement;
//     // // let context = canvas.getContext('2d');

//     // //  var x = canvas.width / 2;
//     // // var y = canvas.height / 2;
//     // let context: CanvasRenderingContext2D = this.layout.nativeElement.getContext("2d");
//     // var x = canvas.width / 2;
//     // var y = canvas.height / 2;
    
//     // context.font = '90pt Calibri';
//     // context.textAlign = 'center';
//     // context.fillStyle = 'blue';
//     // context.fillText('Hello Worldetrereygerhg!', x, y);
    

// // Method 2



//  // end of AfterViewInit



//   // doit(ctx) {
//   //   alert("triggered");
//   //        var width = this.canvas.nativeElement.clientWidth,
//   //          height = this.canvas.nativeElement.clientHeight;

//   //      var fontSize = (height / 250).toFixed(2);
//   //      ctx.font = fontSize + "em Verdana";
//   //      ctx.textBaseline = "middle";
//   //      ctx.fillStyle = "blue";

//   //          var text = "Pass Rate 82%",
//   //          textX = Math.round((width - ctx.measureText(text).width) / 2),
//   //          textY = height -10;

//   //      ctx.fillText(text, textX, textY);
//   //      ctx.restore();
//   //  }

//    public pieChartLabels:string[] = ['Wind Energy', 'Total Energy', 'Nuclear Energy'];
//    public pieChartData:number[] =[300, 500, 10];
//    public pieChartType:string = 'pie';
  
//    public chartClicked(e:any):void {
    
//    }
  
//    public chartHovered(e:any):void {
   
//    }

  









// // widget 2
// public doughnutChartLabels:string[] = ['Wind Energy'];
// public doughnutChartData:number[] = [];
// public doughnutChartType:string = 'doughnut';
// private doughnutChartColors: any[] = [
//   { 
//     backgroundColor: ["rgba(255, 177, 61, 0.63)", "rgba(255,255,255,.3)"],
//     //borderColor: 'black'
//    }  
   
// ];
// public doughnutChartOptions: any = {
//  cutoutPercentage:45,
//  responsive: false,
//  animaiton: {
//   animateRotate: true,
//   animateScale: true,
//   animationDuration: 111,
//   rotation:1000,
//   duration:8000
//  }, 
//   elements: {
//     center: {
//      // text: this.errornumber + "%" +"Energy produced by the Wind", 
//       text: this.errornumber +"% <br>Energy produced <br> by Wind Today" ,
//       //fontColor: '#fff',
//       //fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
     
//       fontFamily:"'Arial'",
//       //fontSize: ,
//       fontStyle: 'Bold Italic'
//     }
//   }
// };

// // events
// public chartClicked1(e:any):void {
//   console.log(e);
// }
// public chartHovered1(e:any):void {
//   console.log(e);
// }






// //widget 2





// public doughnutChartDataEmission:number[] = [40,60];
// private doughnutChartColorsEmission: any[] = [
//   { 
//     backgroundColor: ["rgba(255, 177, 61)", "rgba(255,255,255,.3)"],
//     //borderColor: 'black'
//    }  
   
// ];




// public doughnutChartLabels3:string[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
// public doughnutChartData3:number[] = [350, 450, 100];
// public doughnutChartType3:string = 'doughnut';



//   public chartClicked3(e:any):void {
//     console.log(e);
//   }
 
//   public chartHovered3(e:any):void {
//     console.log(e);
//   }














// } // end of component



